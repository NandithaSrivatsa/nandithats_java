package com.tns.fooddeliverysystem.application;

import java.util.Scanner;
import com.tns.fooddeliverysystem.entities.*;
import com.tns.fooddeliverysystem.services.*;

public class FoodDeliverySystem {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        FoodService foodService = new FoodService();
        OrderService orderService = new OrderService();

        while (true) {

            System.out.println("Admin Menu:");
            System.out.println("1. Add Restaurant");
            System.out.println("2. Add Food Item to Restaurant");
            System.out.println("3. Remove Food Item from Restaurant");
            System.out.println("4. View Restaurants and Menus");
            System.out.println("5. View Orders");
            System.out.println("6. Add Delivery Person");
            System.out.println("7. Assign Delivery Person to Order");
            System.out.println("8. Exit");
            System.out.println();

            System.out.print("Choose an option: ");
            System.out.println();
            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("Enter Restaurant ID: ");
                    int rId = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter Restaurant Name: ");
                    String rName = sc.nextLine();

                    foodService.addRestaurant(new Restaurant(rId, rName));
                    System.out.println("Restaurant added successfully!");
                    System.out.println();
                    break;

                case 2:
                    System.out.print("Enter Restaurant ID: ");
                    int restId = sc.nextInt();

                    System.out.print("Enter Food Item ID: ");
                    int fId = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter Food Item Name: ");
                    String fName = sc.nextLine();

                    System.out.print("Enter Food Item Price: ");
                    double price = sc.nextDouble();

                    FoodItem foodItem = new FoodItem(fId, fName, price);
                    foodService.addFoodItemToRestaurant(restId, foodItem);

                    System.out.println("Food item added successfully!");
                    System.out.println();
                    break;

                case 3:
                    System.out.print("Enter Restaurant ID: ");
                    int restRemove = sc.nextInt();

                    System.out.print("Enter Food Item ID to remove: ");
                    int foodRemove = sc.nextInt();

                    for (Restaurant r : foodService.getRestaurants()) {
                        if (r.getId() == restRemove) {
                            r.removeFoodItem(foodRemove);
                            System.out.println("Food item removed successfully!");
                            System.out.println();
                        }
                    }
                    break;

                case 4:
                    System.out.println("Restaurants and Menus:");

                    for (Restaurant r : foodService.getRestaurants()) {

                        System.out.println("Restaurant ID: " + r.getId() +
                                ", Name: " + r.getName());

                        for (FoodItem f : r.getMenu()) {
                            System.out.println("- Food Item ID: " + f.getId() +
                                    ", Name: " + f.getName() +
                                    ", Price: Rs. " + f.getPrice());
                        }
                    }
                    break;

                case 5:
                    System.out.println("Orders:");

                    for (Order o : orderService.getOrders()) {
                        System.out.println(o);
                    }
                    break;

                case 6:
                    System.out.print("Enter Delivery Person ID: ");
                    int dpId = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter Delivery Person Name: ");
                    String dpName = sc.nextLine();

                    System.out.print("Enter Contact No: ");
                    long contact = sc.nextLong();

                    DeliveryPerson dp = new DeliveryPerson(dpId, dpName, contact);
                    orderService.addDeliveryPerson(dp);

                    System.out.println("Delivery person added successfully!");
                    System.out.println();
                    break;

                case 7:
                    System.out.print("Enter Order ID: ");
                    int orderId = sc.nextInt();

                    System.out.print("Enter Delivery Person ID: ");
                    int deliveryId = sc.nextInt();

                    orderService.assignDeliveryPerson(orderId, deliveryId);

                    System.out.println("Delivery person assigned to order successfully!");
                    System.out.println();
                    break;

                case 8:
                    System.out.println("Exiting Admin Module");
                    return;

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}